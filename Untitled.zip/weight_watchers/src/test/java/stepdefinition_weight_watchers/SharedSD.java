package stepdefinition_weight_watchers;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class SharedSD {

	private static final String URL = "https://www.weightwatchers.com/us/";
	private static WebDriver driver=null;

//	@Given("^I open the default browser$")
	@BeforeMethod
	public static void before() {

		 System.setProperty("webdriver.chrome.driver", "/Users/fatemaislam/Downloads/chromedriver");   
		 driver=new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(URL);
	}

	//@Then("^I close the default browser$")
	@AfterMethod
	public static void after() {
		if (driver != null) {
			driver.manage().deleteAllCookies();
			driver.quit();
		}
	}

	public static WebDriver getDriver() {
		return driver;
	}
}

