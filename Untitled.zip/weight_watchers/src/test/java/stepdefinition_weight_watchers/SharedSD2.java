package stepdefinition_weight_watchers;

import org.testng.annotations.Test;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SharedSD2 {
	private static final String URL = "https://www.weightwatchers.com/us/";
	private static WebDriver driver=null;
	@Test
	public static void before() {

		 System.setProperty("webdriver.chrome.driver", "/Users/fatemaislam/Downloads/chromedriver");   
		 driver=new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(URL);
	}
}
