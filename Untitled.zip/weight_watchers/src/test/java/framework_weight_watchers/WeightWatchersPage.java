package framework_weight_watchers;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;

import stepdefinition_weight_watchers.SharedSD;

public class WeightWatchersPage extends BasePage{
	
	private By findStudio=By.xpath("//span[@text()='Find a Studio']");
	private By meetingSearch=By.xpath("//input[@id='meetingSearch']");
	private By arrowSign=By.xpath("//button[@class='btn spice-translated']");
	private By locationName=By.xpath("//span[contains(text(),'WW Studio Flatiron')]");
	private By distance=By.xpath("//div[contains(text(),'0.49 mi.')]");
	private By todaysOperation=By.xpath("//div[@class='schedule-detailed-day'][2]");
	private By signBtn=By.xpath("//input[@type='submit'][@value='Sign in']");
	
	public void clickOnFindStudio() {
		clickOn(findStudio);
		}
    public void enterSearch(CharSequence[] number) {
		enterNumber(meetingSearch, number);
	}
	public void clickOnArrow() {
		clickOn(arrowSign);
		
	}
	public void getLocation() {
		getTextFromElement(locationName);
	}
	public void getDistance() {
		getTextFromElement(distance);
	}
	public void verifyTheLocation() {
		String actualTitle = SharedSD.getDriver().findElement(By.xpath("//span[contains(text(),'WW Studio Flatiron')]")).getText();
		String expectedTitle = "WW Studio Flatiron";
		assertEquals(actualTitle, expectedTitle);
	}
	public void getTodaysOperation() {
		getTextFromElement(todaysOperation);
	}
}
